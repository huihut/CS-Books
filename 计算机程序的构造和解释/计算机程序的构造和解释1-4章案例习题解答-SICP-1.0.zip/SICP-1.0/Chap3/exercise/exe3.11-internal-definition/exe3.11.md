- 调用(define acc (make-account 50))

  ![](a.jpg)


- 调用 ((acc 'deposit) 40) 和 ((acc 'withdraw) 60)

  ![](b.jpg)


- 调用(define acc2 (make-account 100))

  ![](c.jpg)
