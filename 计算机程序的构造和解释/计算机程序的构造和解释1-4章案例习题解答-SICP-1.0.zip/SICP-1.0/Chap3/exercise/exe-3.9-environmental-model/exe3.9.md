- a)

  ![](a.jpg)

- b)

  ![](b.jpg)