- 注意 set-car! 和 set-cdr! 分别修改的是car和cdr的指针。

  ![](a.jpg)
