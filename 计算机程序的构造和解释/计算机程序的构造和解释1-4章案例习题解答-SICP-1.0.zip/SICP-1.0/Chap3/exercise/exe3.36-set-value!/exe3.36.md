```
(define a (make-connector))
(define b (make-connector))
```
![](a.jpg)


```
(set-value! a 10 'user)
```
![](b.jpg)