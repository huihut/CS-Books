# Effective Java Examples

Diese Quelltexte stammen aus dem Buch "Effective Java Second Edition", geschrieben von Joshua Bloch.

Die Quellen sind beinahe unverändert. Lediglich die Packetnamen wurden von mir angepasst.

Die Originalquellen können hier herunter geladen werden: http://java.sun.com/docs/books/effective/index.html

