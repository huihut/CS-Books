package org.effectivejava.examples.chapter05.item26.secondtechnqiue;

public class EmptyStackException extends RuntimeException {
}
