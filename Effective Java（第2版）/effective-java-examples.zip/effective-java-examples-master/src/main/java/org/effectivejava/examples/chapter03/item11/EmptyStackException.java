package org.effectivejava.examples.chapter03.item11;

public class EmptyStackException extends IllegalStateException {
}
