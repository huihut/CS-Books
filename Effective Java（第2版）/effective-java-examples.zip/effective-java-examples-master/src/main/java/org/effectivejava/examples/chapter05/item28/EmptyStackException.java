package org.effectivejava.examples.chapter05.item28;

public class EmptyStackException extends RuntimeException {
}
